Hey enjoy my IRs, load it on you favorite Impulse Reponse VST plugin (NadIR, Pulse,  KefIR, etc...)
The tone of these IR for guitar copyright belong to Pantera, well Vinnie Paul (main producer of these albums in general)

This pack will be updated as soon as I can find different tone from Pantera.... 

the 3 essentials now in this pack are:

pantera-power.wav (Powermetal)
pantera-power(DownBelow)_IR.wav (Powermetal)
pantera-cowboy_IR.wav (Cowboy From Hell)
Pantera-Walk_IR.wav (Vulgar Display Of Power)
panthera-Broken_IR.wav (Far Beyond Driven)

BGelais

